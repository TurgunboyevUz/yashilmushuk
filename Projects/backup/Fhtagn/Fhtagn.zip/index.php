<?php

require 'triangle.php';

if (isset($argv)) {
    main();
}
